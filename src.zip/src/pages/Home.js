
import { BossList } from "../components"

function Home() {
  return (
    <div style={{margin: 'auto'}}>
        <BossList />
    </div>
  );
}

export default Home;