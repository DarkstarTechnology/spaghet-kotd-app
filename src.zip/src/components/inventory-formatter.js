import * as React from 'react';
import useSWR from 'swr';
import {MarkdownBlock, MarkdownSpan, MarkdownElement} from "https://md-block.verou.me/md-block.js";


// created function to handle API request
const fetcher = (...args) => fetch(...args).then((res) => res.json());

const flatten = (array) => {
    let result = [];
    array.forEach(function (a) {
      result.push(a);
      if (a.data.replies && a.data.replies.data && Array.isArray(a.data.replies.data.children)) {
        result = result.concat(flatten(a.data.replies.data.children));
      }
    });
    return result;
  }

const InventoryFormmater = ({ link }) => {

    const {
        data: res,
        error,
        isValidating,
      } = useSWR(link, fetcher, { revalidateOnFocus: false});
    
      // Handles error and loading state
      if (error) return <div className='failed'>failed to load</div>;
      if (isValidating) return <div className="Loading">Loading...</div>;
      
    
      let comments = res.length > 1 && res[1].data ? flatten(res[1].data.children).map(rawComments => rawComments.data) : [];
      if(!comments.length) return <h3>No recent comments on r/KickOpenTheDoor</h3>
      
      let inventoryTables = comments[1].body.split('-----').filter(table => { return table.indexOf('|ID|Type|Name|') > -1});
    
      return (
        <div>{inventoryTables.length &&
            inventoryTables.map((table, index) => (
                <md-block key={index}>{table}</md-block>
            ))}
        </div>
      );
};

export { InventoryFormmater };