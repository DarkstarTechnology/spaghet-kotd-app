import * as React from 'react';
import useSWR from 'swr';
// import { PlayerComments } from "./"
import { BossDetails } from "./"

import Grid from '@mui/material/Unstable_Grid2';

// Import useSWR from swr package

// created function to handle API request
const fetcher = (...args) => fetch(...args).then((res) => res.json());

const BossList = () => {
  const {
    data: res,
    error,
    isValidating,
  } = useSWR('https://www.reddit.com/r/kickopenthedoor/search.json?q=flair%3A%E2%9D%A4%EF%B8%8F+NOT+flair%3Aslain+NOT+flair%3Aexecuted+NOT+title%3A%22%5Bslime+only%5D%22&restrict_sr=1&raw_json=1', fetcher, { revalidateOnFocus: false });

  // Handles error and loading state
  if (error) return <div className='failed'>failed to load</div>;
  if (isValidating) return <div className="Loading">Loading...</div>;
  let totalDamage = 0;
  let bossees = res.data.children.map(bossRaw => bossRaw.data).map(boss => {
    const rawHealth = boss.link_flair_text.match(/\d+([/.]\d+)?/g)[0].split('/');
    const healthObj = { currentHealth: +rawHealth[0], maxHealth: +rawHealth[1] };
    const stars = boss.link_flair_text.split('★').length - 1;

    let maxDMG = Math.ceil(0.08 * healthObj.maxHealth ** 0.15 * healthObj.currentHealth ** 0.5 * stars ** 1.7);
    console.log(healthObj.currentHealth)
    console.log(maxDMG)
    totalDamage += maxDMG;

    let bossData = {
      title: boss.title.split(' [')[0],
      stars: boss.link_flair_text.split('★').length - 1,
      health: healthObj,
      flair: { text: boss.link_flair_text, color: boss.link_flair_background_color },
      thumbnail: boss.thumbnail,
      image: boss.preview && boss.preview.images ? boss.preview.images[0].source.url : boss.thumbnail,
      maxGold: Math.floor((0.086 * healthObj.maxHealth ** 0.547 * (healthObj.maxHealth - healthObj.currentHealth) ** 0.263 + 10) * stars ** 0.167),
      maxDmg: maxDMG,
      commentData: 'https://www.reddit.com' + boss.permalink.slice(0, -1) + '.json',
      permalink: 'https://www.reddit.com' + boss.permalink
    };
    return bossData;
  }).filter(boss => boss.health.currentHealth > 1).sort((a, b) => (a.health.currentHealth < b.health.currentHealth ? -1 : 1));

  let width = 3;
  if(bossees.length <= 3) {
    width = Math.floor(12/bossees.length)
  }
  return (
    <>
      <h3 style={{color: '#FFFFFF'}}>Total Max Damage: 💥{totalDamage}</h3>
      <Grid container spacing={1} alignItems="center" justifyContent="center" sx={{maxWidth: '100%'}}>
        {bossees &&
          bossees.map((boss, index) => (
            <Grid xs={10} sm={10} md={width * 2} lg={width} key={boss.permalink} alignItems="center" justifyContent="center">
              <BossDetails boss={boss} />
            </Grid>
          ))}
      </Grid>
    </>
  );
};

export { BossList };