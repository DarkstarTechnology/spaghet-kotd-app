import * as React from 'react';
import { InventoryFormmater } from './';
import Moment from 'react-moment';
import useSWR from 'swr';


// created function to handle API request
const fetcher = (...args) => fetch(...args).then((res) => res.json());

const PlayerInventory = () => {

  let storedPlayerName = localStorage.getItem('storedPlayerName');

  window.addEventListener('kotdPlayerUpdate', () => {
    storedPlayerName = localStorage.getItem('storedPlayerName');
  });

  const {
    data: res,
    error,
    isValidating,
  } = useSWR(`https://www.reddit.com/user/${storedPlayerName}/comments.json?sort=new`, fetcher, { revalidateOnFocus: false});

  // Handles error and loading state
  if (error) return <div className='failed'>failed to load</div>;
  if (isValidating) return <div className="Loading">Loading...</div>;

  if(!storedPlayerName) return <h3>Enter a username</h3>
  

  let comments = res.data.children.map(comment => comment.data).filter(comment => { return comment.body.indexOf('!inventory') > -1; });

  if(!comments.length) {
    return <div className='failed'>No recent !inventory call found! Please pull your inventory on Reddit to see it here.</div>
  }
  let lastPollSeconds = comments[0].created;
  let lastPoll = new Date(lastPollSeconds*1000);
  
  console.log(lastPoll.toJSON())
  let inventoryCommentURL = 'https://www.reddit.com/' + comments[0].permalink + '.json'

  return (
    <div style={{color: '#FFFFFF'}}>
      <br/>
      Last Inventory Check: <Moment fromNow>{lastPoll}</Moment>
      <br/><br/>
      <>{storedPlayerName ? <InventoryFormmater link={inventoryCommentURL} /> : 'Enter a username'}</>
    </div>
  );
};

export { PlayerInventory };