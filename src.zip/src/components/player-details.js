import * as React from 'react';
import { useState, useEffect } from 'react'
import Paper from '@mui/material/Paper';
import InputBase from '@mui/material/InputBase';
import IconButton from '@mui/material/IconButton';
import Button from '@mui/material/Button';
import SaveAltRoundedIcon from '@mui/icons-material/SaveAltRounded';
import DeleteIcon from '@mui/icons-material/Delete';

// created function to handle API request

const PlayerDetails = () => {

  let [newPlayerName, setNewPlayerName] = useState('');
  let [storedPlayerName, setStoredPlayerName] = useState('');

  useEffect(() => {
    // Get the value from localStorage when the component mounts
    let storedPlayerName = localStorage.getItem('storedPlayerName');
    if (storedPlayerName) {
      setStoredPlayerName(storedPlayerName);
      window.dispatchEvent(new Event("kotdPlayerUpdate"));
    }
  }, []);

  const clearPlayer = (e) => {
    setStoredPlayerName('');
    localStorage.setItem('storedPlayerName', '');
    setNewPlayerName('');
    window.dispatchEvent(new Event("kotdPlayerUpdate"));
    window.location.reload();
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    // Save the input value to localStorage
    localStorage.setItem('storedPlayerName', newPlayerName);
    setStoredPlayerName(newPlayerName);
    window.location.reload();
  };

  return (
    <div>
      {storedPlayerName ? (
        <h3>{storedPlayerName} <Button  sx={{ color: 'white' }} variant="outlined" onClick={(e) => clearPlayer(e)} startIcon={<DeleteIcon />}></Button></h3>
      ) : (
        <form onSubmit={handleSubmit}>
        <Paper
            sx={{ p: '2px 4px', display: 'flex', alignItems: 'center', maxWidth: 200 }}>
            <InputBase
              sx={{ flex: 1 }}
              placeholder="Reddit Username"
              inputProps={{}}
              onChange={(e) => setNewPlayerName(e.target.value)}
              value={newPlayerName}
            />
            <IconButton type="submit" aria-label="Set Player" className={'ClearButton'} >
              <SaveAltRoundedIcon />
            </IconButton>
          </Paper>
        </form>
      )}
    </div>
  );
};

export { PlayerDetails };