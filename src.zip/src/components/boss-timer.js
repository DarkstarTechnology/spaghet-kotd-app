import * as React from 'react';
import { CountdownCircleTimer } from 'react-countdown-circle-timer'

// created function to handle API request

const renderTime = (dimension, time) => {
  return (
    <div className="time-wrapper">
      <div className="time">{time}</div>
      <div>{dimension}</div>
    </div>
  );
};

const BossTimer = ({ data }) => {
  const boss = data.boss;
  const expireTime = data.expireTime
  const nowDateTime = new Date();
  const timeLeft = expireTime ? ((expireTime.getTime() - nowDateTime.getTime()) / 1000) : 0;


  const minuteSeconds = 60;
  const hourSeconds = 3600;
  //const daySeconds = 86400;


  const getTimeMinutes = (time) => ((time % hourSeconds) / minuteSeconds) | 0;
  const getTimeSeconds = (time) => (minuteSeconds - time) | 0;

  if(navigator.serviceWorker) {
    navigator.serviceWorker.register('sw.js');
    Notification.requestPermission(function (result) {});
  }




  return (
      <CountdownCircleTimer
        isPlaying
        size="100"
        strokeWidth="6"
        colors={boss.flair.color}
        duration={hourSeconds}
        initialRemainingTime={timeLeft % hourSeconds}
        onComplete={(totalElapsedTime) => {
          if(navigator.serviceWorker) {
            navigator.serviceWorker.ready.then(function (registration) {
              registration.showNotification(`Come hit ${boss.title}!`);
            });
          }
        }}
      >
        {({ elapsedTime, color }) => {
          if((hourSeconds - elapsedTime) > 0) {
            return (
              <span style={{ fontSize: '13px', marginTop: '-15px' }}>
                {renderTime("minutes", getTimeMinutes(hourSeconds - elapsedTime))}
                {renderTime("seconds", getTimeSeconds(elapsedTime % minuteSeconds))}
              </span>
            )
          } else {
            return (<h5>GO!</h5>)
          }
        }}
      </CountdownCircleTimer>
  );
};

export { BossTimer };