import * as React from 'react';
import { useState } from "react";
import useSWR from 'swr';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardMedia from '@mui/material/CardMedia';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import OfflineBoltRoundedIcon from '@mui/icons-material/OfflineBoltRounded';
import Link from '@mui/material/Link';
import LinearProgress, { linearProgressClasses } from '@mui/material/LinearProgress';
import { CopyToClipboardButton } from './';

import { BossTimer } from './boss-timer';


// created function to handle API request
const fetcher = (...args) => fetch(...args).then((res) => res.json());

const flatten = (array) => {
  let result = [];
  array.forEach(function (a) {
    result.push(a);
    if (a.data.replies && a.data.replies.data && Array.isArray(a.data.replies.data.children)) {
      result = result.concat(flatten(a.data.replies.data.children));
    }
  });
  return result;
}

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
  marginLeft: 'auto',
  transition: theme.transitions.create('transform', {
    duration: theme.transitions.duration.shortest,
  }),
}));
  
const BorderLinearProgress = styled(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor: theme.palette.grey[200],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: '#ff0000',
  },
}));

const BossDetails = ({ boss }) => {

  let storedPlayerName = localStorage.getItem('storedPlayerName');

  window.addEventListener('kotdPlayerUpdate', () => {
    storedPlayerName = localStorage.getItem('storedPlayerName');
  });

  const [expanded, setExpanded] = React.useState(false);
  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const [refreshInterval, setRefresh] = useState(0);

  const updateBoss = function(rawBoss) {
    const rawHealth = rawBoss.link_flair_text.match(/\d+([/.]\d+)?/g)[0].split('/');
    const healthObj = { currentHealth: +rawHealth[0], maxHealth: +rawHealth[1] };
    const stars = rawBoss.link_flair_text.split('★').length - 1;
    const specials = /\[(.*?)\]/.exec(rawBoss.title);

    return {
      title: rawBoss.title.split(' [')[0],
      specials: specials != null && specials.length && !specials[1].startsWith('Health') ? specials[1] : '',
      stars: rawBoss.link_flair_text.split('★').length - 1,
      health: healthObj,
      flair: { text: rawBoss.link_flair_text, color: rawBoss.link_flair_background_color },
      thumbnail: rawBoss.thumbnail,
      image: rawBoss.thumbnail, //rawBoss.preview && rawBoss.preview.images.length ? rawBoss.preview.images[0].source.url : rawBoss.thumbnail,
      maxGold: Math.floor((0.086 * healthObj.maxHealth ** 0.547 * (healthObj.maxHealth - healthObj.currentHealth) ** 0.263 + 10) * stars ** 0.167),
      maxDmg: Math.ceil(0.08 * healthObj.maxHealth ** 0.15 * healthObj.currentHealth ** 0.5 * stars ** 1.7),
      commentData: 'https://www.reddit.com' + rawBoss.permalink.slice(0, -1) + '.json',
      permalink: 'https://www.reddit.com' + rawBoss.permalink
    }
  }

  const {
    data: res,
    error,
    isValidating,
  } = useSWR(boss.commentData, fetcher, { revalidateOnFocus: false, refreshInterval: (refreshInterval * 1000) });

  // Handles error and loading state
  if (error) return <div className='failed'>failed to load</div>;
  if (isValidating) return <div className="Loading">Loading...</div>;

  if(res.length && res[0].data.children.length) {
    boss = updateBoss(res[0].data.children[0].data);
  }
  

  let comments = res.length > 1 && res[1].data ? flatten(res[1].data.children).map(rawComments => rawComments.data) : [];

  const playerData = comments.filter(comment => (String(comment.author).toLowerCase() === String(storedPlayerName).toLowerCase()));
  playerData.sort((a, b) => (a.created > b.created ? -1 : 1));


  const attackCommnds = [
    '!melee',
    '!magic',
    '!mage',
    '!range',
    '!ranged'
  ];

  const playerHits = playerData.filter(comment => {
    let found = false;
    attackCommnds.forEach(command => {
      if(comment.body.indexOf(command) > -1) {
        found = true;
      }
    });
    return found && comment.replies && 
    comment.replies.data.children.length &&
    comment.replies.data.children[0].data.author === "KickOpenTheDoorBot" && 
    comment.replies.data.children[0].data.body.indexOf('💥') > -1;
  });  

  const lastHit = playerHits.length ? new Date(playerHits[0].created * 1000) : 0;
  const expireTime = lastHit ? new Date(lastHit.getTime() + 3600000) : 0;
  const lastCommand = playerHits.length ? playerHits[0].body.split('\\').join('') : '';


  return (
    <Card sx={{ maxWidth: '100%', border: 5, borderColor: boss.flair.color }}>
      <CardHeader
        title={
          <div>
            <Link href={boss.permalink} underline="none" target="_blank" rel="noreferrer" title={boss.title}>
              <Typography gutterBottom variant="h5" component="div" height={35}
                sx={{
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "pre-line",
                  display: "-webkit-box",
                  WebkitLineClamp: "1",
                  WebkitBoxOrient: "vertical",
                }}
              >
                {boss.specials ? boss.specials + ' - ' : ''} {boss.title}
              </Typography>
            </Link>
            <Typography variant="h5" color="text.secondary">
              {boss.flair.text.split("★ ")[0] + '★'}
            </Typography>
            <Typography variant="h5" color="text.secondary">
              {boss.health.currentHealth}/{boss.health.maxHealth}
            </Typography>
          </div>
        }
      />
      <BorderLinearProgress variant="determinate" value={(boss.health.currentHealth / boss.health.maxHealth) * 100} label="test" sx={{'& .MuiLinearProgress-bar1Determinate': {backgroundColor: boss.flair.color}, borderRadius: '0px'}} >Test</BorderLinearProgress>
      <CardMedia
        component="img"
        height="200"
        width="100%"
        image={boss.image}
        alt={boss.title}
      />
      <CardContent>
        {storedPlayerName ? <BossTimer data={{boss, expireTime}} /> : 'Enter a username'}
      </CardContent>
      <Collapse in={expanded} timeout="auto" unmountOnExit>
        <CardContent>
          <Typography variant="body2" color="text.secondary">
            {lastCommand} 
          </Typography>
          <CopyToClipboardButton text={lastCommand} />
        </CardContent>
      </Collapse>
      <CardActions disableSpacing>
        <IconButton aria-label="Max Gold">
          {boss.maxGold} <MonetizationOnIcon />
        </IconButton>
        <IconButton aria-label="Max DMG">
          {boss.maxDmg} <OfflineBoltRoundedIcon />
        </IconButton>
        <FormControl sx={{ m: 1, minWidth: 110 }}  size="small">
          <InputLabel id="refresh-interval-label">Refresh</InputLabel>
          <Select
            labelId="refresh-interval-label"
            id="refresh-interval"
            value={refreshInterval}
            label="Refresh"
            onChange={e => setRefresh(e.target.value)}
          >
            <MenuItem value={0}>Off</MenuItem>
            <MenuItem value={5}>5 Sec</MenuItem>
            <MenuItem value={6.25}>6.25 Sec</MenuItem>
            <MenuItem value={10}>10 Sec</MenuItem>
            <MenuItem value={30}>30 Sec</MenuItem>
            <MenuItem value={60}>1 Min</MenuItem>
          </Select>
        </FormControl>
        <ExpandMore
          expand={expanded}
          onClick={handleExpandClick}
          aria-expanded={expanded}
          aria-label="show more"
        >
          <ExpandMoreIcon />
        </ExpandMore>
      </CardActions>

    </Card>
  );
};

export { BossDetails };